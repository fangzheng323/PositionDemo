//
//  AppDelegate.h
//  PositionDemo
//
//  Created by 方正 on 2016/10/20.
//  Copyright © 2016年 fangz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

