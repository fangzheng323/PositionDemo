//
//  main.m
//  PositionDemo
//
//  Created by 方正 on 2016/10/20.
//  Copyright © 2016年 fangz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
